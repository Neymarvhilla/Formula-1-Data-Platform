# Databricks notebook source
raw_folder_path = "abfss://raw@formula1nesodatalake.dfs.core.windows.net/"
process_folder_path = "abfss://process@formula1nesodatalake.dfs.core.windows.net/"
presentation_folder_path = "abfss://presentation@formula1nesodatalake.dfs.core.windows.net/" 

# COMMAND ----------

raw_folder_path

# COMMAND ----------

process_folder_path

# COMMAND ----------

presentation_folder_path