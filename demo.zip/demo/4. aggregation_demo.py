# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{presentation_folder_path}/final_results_report")

# COMMAND ----------

display(race_results_df)

# COMMAND ----------

races_df = race_results_df.filter(race_results_df["race_year"] == 2020)

# COMMAND ----------

display(races_df)

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum

# COMMAND ----------

# count total races
races_df.select(count(races_df["race_name"])).show()

# COMMAND ----------

# count distinct races
races_df.select(countDistinct(races_df["race_name"])).show()

# COMMAND ----------

races_df.select(sum(races_df["points"])).show()

# COMMAND ----------

# how many points did lewis hamilton get
races_df.filter(races_df["driver_name"] == "Lewis Hamilton").select(sum(races_df["points"])).show()

# COMMAND ----------

# multiple aggregate functions
races_df.filter(races_df["driver_name"] == "Lewis Hamilton").select(sum(races_df["points"]), countDistinct(races_df["race_name"])).show()

# COMMAND ----------

# group by aggregations

# lets create a driver standings table using groupBy
driver_standings_df = races_df.groupBy(races_df["driver_name"]).agg(sum(races_df["points"]), countDistinct(races_df["race_name"]))
driver_standings_df = driver_standings_df.withColumnRenamed("sum(points)", "driver_points").withColumnRenamed("count(race_name)", "no_of_races")
display(driver_standings_df)

# COMMAND ----------

# Window Functions
demo_df = race_results_df.filter("race_year in (2019, 2020)")
display(demo_df)

# COMMAND ----------

standings_demo_df = demo_df.groupBy("race_year", "driver_name").agg(sum("points").alias("total_points"), countDistinct("race_name").alias("number_of_races"))

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc, rank

# COMMAND ----------

driverRankSpec = Window.partitionBy("race_year").orderBy(desc("total_points"))
standings_demo_df.withColumn("rank", rank().over(driverRankSpec)).show()