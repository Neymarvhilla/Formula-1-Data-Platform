# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

circuits_df = spark.read.parquet(f"{process_folder_path}/circuits").filter("circuit_id < 70").withColumnRenamed("name", "circuit_name")
races_df = spark.read.parquet(f"{process_folder_path}/races").withColumnRenamed("name", "race_name")
display(circuits_df)
display(races_df)

# COMMAND ----------

new_races_df = races_df.filter(races_df["race_year"] == 2019)
display(new_races_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Inner Join

# COMMAND ----------

# lets join the two dataframes
# we are joining the two dataframes using a column that have in common (circuit_id)
# we can specify what kind of join we want to do (inner, left, right, outer)
# Inner joins only return the records that satisfy the join condition on both dataframes.
race_circuits_df = circuits_df.join(new_races_df, circuits_df["circuit_id"] == new_races_df["circuit_id"], "inner")
# display the new dataframe
display(race_circuits_df)

# COMMAND ----------

race_circuits_df = race_circuits_df.select(race_circuits_df["circuit_name"], race_circuits_df["location"], race_circuits_df["country"], race_circuits_df["race_name"], race_circuits_df["round"])
display(race_circuits_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Outer Join
# MAGIC

# COMMAND ----------

# Outer Joins return records that satisfy the join the condition as well as records that do not satisfy the join condition.
# Left outer Join - the left dataframe is fixed in this case and we get all the values regardless of whether the join condition is satisfied or not. However, only the records that satisfy the join condition are returned from the right dataframe. Right outer join is the inverse of this.
# Full outer join - returns all the records from both dataframes regardless of whether the join condition is satisfied or not.


# COMMAND ----------

# left outer join
race_circuits_df = circuits_df.join(new_races_df, circuits_df["circuit_id"] == new_races_df["circuit_id"], "left")
display(race_circuits_df)