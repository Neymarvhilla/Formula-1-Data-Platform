-- Databricks notebook source
-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Lesson Objectives
-- MAGIC 1. Spark SQL documentation
-- MAGIC 2. Create Database demo
-- MAGIC 3. Data tab in the UI
-- MAGIC 4. SHOW command
-- MAGIC 5. DESCRIBE command
-- MAGIC 6. Find the current database

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS demo;

-- COMMAND ----------

SHOW databases

-- COMMAND ----------

DESCRIBE DATABASE  EXTENDED demo;

-- COMMAND ----------

SELECT CURRENT_DATABASE();

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

USE demo;

-- COMMAND ----------

SELECT CURRENT_DATABASE();

-- COMMAND ----------

SHOW TABLES IN default

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Learning Objectives
-- MAGIC 1. Create managed table using Python
-- MAGIC 2. Create managed table using SQL
-- MAGIC 3. Effect of dropping a managed table
-- MAGIC 4. Describe table

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # creating a managed table using python
-- MAGIC race_results_df = spark.read.parquet(f"{presentation_folder_path}/final_results_report")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo.race_results_python")
-- MAGIC

-- COMMAND ----------

USE demo;
SHOW TABLES;

-- COMMAND ----------

DESC EXTENDED race_results_python

-- COMMAND ----------

SELECT * FROM race_results_python WHERE race_year = 2020

-- COMMAND ----------

-- create a manged table using sql
CREATE TABLE  race_results_sql AS
SELECT * FROM race_results_python WHERE race_year = 2020


-- COMMAND ----------

SELECT CURRENT_DATABASE()

-- COMMAND ----------

DESC EXTENDED race_results_sql;

-- COMMAND ----------

DROP TABLE demo.race_results_sql;

-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Learning Objectives
-- MAGIC 1. Create external table using Python
-- MAGIC 2. Create external table using SQL
-- MAGIC 3. Effect of dropping an external table

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # creating the external table using python
-- MAGIC race_results_df.write.format("parquet").option("path", f"{presentation_folder_path}/final_results_report_ext_py").saveAsTable("demo.race_results_ext_py")

-- COMMAND ----------

DESC EXTENDED demo.race_results_ext_py

-- COMMAND ----------

DROP TABLE demo.race_results_ext_sql

-- COMMAND ----------

-- creating the external table using sql

CREATE TABLE demo.race_results_ext_sql
(
  race_year INT,
  race_name STRING,
  race_date STRING,
  circuit_location STRING,
  driver_name STRING,
  driver_number INT,
  driver_nationality STRING,
  team STRING,
  grid INT,
  fastest_lap INT,
  race_time STRING,
  points FLOAT,
  position INT,
  created_date TIMESTAMP
)
USING parquet
LOCATION "abfss://presentation@formula1nesodatalake.dfs.core.windows.net/race_results_ext_sql"

-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

-- we will take values from our other external table we made using python and insert it into our sql external table
INSERT INTO demo.race_results_ext_sql
SELECT * FROM demo.race_results_ext_py WHERE race_year = 2020;

-- COMMAND ----------

SELECT COUNT(1) FROM demo.race_results_ext_sql

-- COMMAND ----------

-- when you create an external table, you have to insert data into it before it would be stored in your storage container

-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

DROP TABLE demo.race_results_ext_sql

-- COMMAND ----------

SHOW TABLES IN demo;

-- COMMAND ----------

-- Recap: the difference between managed and external tables is that with managed tables spark maintains both metadata and data, but in external tables spark only maintains the metadata and we externally maintain the data.

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Views on tables
-- MAGIC ## Learning Objectives
-- MAGIC 1. Create Temp view
-- MAGIC 2. Create Global Temp View
-- MAGIC 3. Create Permanent view

-- COMMAND ----------

-- Creating a temporary view
CREATE OR REPLACE TEMP VIEW v_race_results
AS
SELECT *
FROM race_results_python
WHERE race_year = 2020

-- COMMAND ----------

SELECT * FROM v_race_results

-- COMMAND ----------

USE demo

-- COMMAND ----------

CREATE OR REPLACE GLOBAL TEMP VIEW v_race_results
AS
SELECT *
FROM demo.race_results_python
WHERE race_year = 2018;

-- COMMAND ----------

-- creating a permanent view
CREATE OR REPLACE VIEW demo.pv_race_results
AS
SELECT *
FROM demo.race_results_python
WHERE race_year = 2000

-- COMMAND ----------

SHOW TABLES;