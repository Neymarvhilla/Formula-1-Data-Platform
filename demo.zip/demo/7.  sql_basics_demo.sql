-- Databricks notebook source
-- to see our databses
SHOW DATABASES;

-- COMMAND ----------

-- To look at data in a particular databses
USE f1_presentation;

-- COMMAND ----------

-- To look at the tables in a databses
SHOW TABLES

-- COMMAND ----------

USE f1_processed;

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

SELECT *
FROM drivers


-- COMMAND ----------

-- to see the list of columns
DESC drivers

-- COMMAND ----------

SELECT *
FROM drivers
LIMIT 10

-- COMMAND ----------

SELECT *
FROM drivers
WHERE nationality = "British"
LIMIT 10

-- COMMAND ----------

SELECT *
FROM drivers
WHERE nationality = "British" AND dob > "1990-12-31"

-- COMMAND ----------

SELECT name, dob AS date_of_birth
FROM drivers
WHERE nationality = "British" AND dob >= "1990-01-01"
ORDER BY dob
LIMIT 10

-- COMMAND ----------

SELECT *
FROM drivers
ORDER BY nationality ASC, dob DESC

-- COMMAND ----------

SELECT *
FROM drivers
WHERE (nationality = "British" AND dob >= "1990-01-01") 
OR (nationality = "Indian")
ORDER BY dob DESC

-- COMMAND ----------

