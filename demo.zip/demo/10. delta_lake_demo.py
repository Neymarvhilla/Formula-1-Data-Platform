# Databricks notebook source
# MAGIC %md
# MAGIC  1. Write data to delta lake (managed table)
# MAGIC  2. Write data to delta lake (external table)
# MAGIC  3. Read data from delta lake (Table)
# MAGIC  4. Read data from delta lake (file)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- create the database with the location where the tables would be stored
# MAGIC CREATE DATABASE IF NOT EXISTS f1_demo
# MAGIC LOCATION "abfss://demo@formula1nesodatalake.dfs.core.windows.net/"

# COMMAND ----------

# read data to create a data frame with spark
results_df = spark.read.option("inferSchema", True).json("abfss://raw@formula1nesodatalake.dfs.core.windows.net/2021-03-28/results.json")

# COMMAND ----------

# writing data to a delta lake managed table
results_df.write.format("delta").mode("overwrite").saveAsTable("f1_demo.results_managed")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_demo.results_managed;

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").save("abfss://demo@formula1nesodatalake.dfs.core.windows.net/results_external.json")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- creating an external table
# MAGIC CREATE TABLE f1_demo.results_external
# MAGIC USING DELTA
# MAGIC LOCATION "abfss://demo@formula1nesodatalake.dfs.core.windows.net/results_external.json"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_demo.results_external

# COMMAND ----------

result_external_df = spark.read.format("delta").load("abfss://demo@formula1nesodatalake.dfs.core.windows.net/results_external.json")

# COMMAND ----------

display(result_external_df)

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").partitionBy("constructorId").saveAsTable("f1_demo.results_partitioned")

# COMMAND ----------

# MAGIC %md
# MAGIC 1. Update Delta Table
# MAGIC 2. Delete From Delta Table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM f1_demo.results_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- updating tables
# MAGIC UPDATE f1_demo.results_managed
# MAGIC   SET points = 11 - position
# MAGIC WHERE position <= 10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_demo.results_managed

# COMMAND ----------

# Python equivalence
from delta.tables import DeltaTable
deltaTable = DeltaTable.forPath(spark, "abfss://demo@formula1nesodatalake.dfs.core.windows.net/results_managed")
deltaTable.update("position <= 10", {"points": "21 - position"})

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_demo.results_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM f1_demo.results_managed
# MAGIC WHERE position < 10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM f1_demo.results_managed

# COMMAND ----------

# Python equivalence
from delta.tables import DeltaTable
deltaTable = DeltaTable.forPath(spark, "abfss://demo@formula1nesodatalake.dfs.core.windows.net/results_managed")
deltaTable.delete("points = 0")

# COMMAND ----------

# MAGIC %md
# MAGIC Upsert using merge

# COMMAND ----------

drivers_day_1 = spark.read.option("inferSchema", True).json("abfss://raw@formula1nesodatalake.dfs.core.windows.net/2021-03-28/drivers.json").filter("driverId <= 10").select("driverId", "dob", "name.forename", "name.surname")

# COMMAND ----------

display(drivers_day_1)

# COMMAND ----------

from pyspark.sql.functions import upper
driver_day2_df = spark.read.option("inferSchema", True).json("abfss://raw@formula1nesodatalake.dfs.core.windows.net/2021-03-28/drivers.json").filter("driverId BETWEEN 6 AND 15").select("driverId", "dob", upper("name.forename").alias("forename"), upper("name.surname").alias("surname"))

# COMMAND ----------

display(driver_day2_df)

# COMMAND ----------

from pyspark.sql.functions import upper
driver_day3_df = spark.read.option("inferSchema", True).json("abfss://raw@formula1nesodatalake.dfs.core.windows.net/2021-03-28/drivers.json").filter("driverId BETWEEN 1 AND 5 OR driverId BETWEEN 10 AND 20").select("driverId", "dob", upper("name.forename").alias("forename"), upper("name.surname").alias("surname"))

# COMMAND ----------

display(driver_day3_df)

# COMMAND ----------

drivers_day_1.createOrReplaceTempView("drivers_day1")
driver_day2_df.createOrReplaceTempView("drivers_day2")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- lets create a delta table
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.drivers_merge(
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createdDate DATE,
# MAGIC   updatedDate DATE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %md
# MAGIC ## Day 1

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.drivers_merge tgt
# MAGIC USING drivers_day1 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC     UPDATE SET tgt.dob = upd.dob, tgt.forename = upd.forename, tgt.surname = upd.surname, tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC     THEN INSERT(driverId, dob, forename, surname, createdDate) VALUES (driverId, dob, forename, surname, current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_merge;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Day 2

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.drivers_merge tgt
# MAGIC USING drivers_day2 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC     UPDATE SET tgt.dob = upd.dob, tgt.forename = upd.forename, tgt.surname = upd.surname, tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC     THEN INSERT(driverId, dob, forename, surname, createdDate) VALUES (driverId, dob, forename, surname, current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_merge;

# COMMAND ----------

from delta.tables import *
from pyspark.sql.functions import current_timestamp
deltaTable = DeltaTable.forPath(spark, "abfss://demo@formula1nesodatalake.dfs.core.windows.net/drivers_merge")
deltaTable.alias("tgt").merge(driver_day3_df.alias("upd"),
                                 "tgt.driverId = upd.driverId")\
                                     .whenMatchedUpdate(set = {"dob" : "upd.dob", "forename":"upd.forename","surname":"upd.surname", "updatedDate":"current_timestamp()"})\
                                         .whenNotMatchedInsert(values = {"driverId": "upd.driverId", "dob" : "upd.dob", "forename": "upd.forename", "surname" : "upd.surname", "createdDate" : "current_timestamp()"}).execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_merge

# COMMAND ----------

# MAGIC %md
# MAGIC 1. History & Versioning
# MAGIC 2. Time Travel
# MAGIC 3. Vaccum
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY f1_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_merge VERSION AS OF 1;

# COMMAND ----------

df = spark.read.format("delta").option("timestampAsof", "2025-05-07T13:12:30.000+00:00").load("abfss://demo@formula1nesodatalake.dfs.core.windows.net/drivers_merge")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM f1_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM f1_demo.drivers_merge WHERE driverId = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demo.drivers_merge VERSION AS OF 3;

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demo.drivers_merge tgt
# MAGIC USING f1_demo.drivers_merge VERSION AS OF 3 src
# MAGIC ON (tgt.driverId = src.driverId) 
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC Transaction Logs

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.drivers_txn (
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createdDate DATE,
# MAGIC   updatedDate DATE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY f1_demo.drivers_txn

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO f1_demo.drivers_txn
# MAGIC SELECT * FROM f1_demo.drivers_merge
# MAGIC WHERE driverId = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY f1_demo.drivers_txn

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO f1_demo.drivers_txn
# MAGIC SELECT * FROM f1_demo.drivers_merge
# MAGIC WHERE driverId = 2

# COMMAND ----------

# MAGIC %md
# MAGIC Convert Parquet to Delta

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demo.convert_to_delta(
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createdDate DATE,
# MAGIC   updatedDate Date
# MAGIC )
# MAGIC USING PARQUET

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO f1_demo.convert_to_delta
# MAGIC SELECT * FROM f1_demo.drivers_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT to DELTA f1_demo.convert_to_delta

# COMMAND ----------

df = spark.table("f1_demo.convert_to_delta")

# COMMAND ----------

df.write.format("parquet").save("abfss://demo@formula1nesodatalake.dfs.core.windows.net/convert_to_delta_new")

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT TO DELTA parquet. `abfss://demo@formula1nesodatalake.dfs.core.windows.net/convert_to_delta_new`