# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Data Lake using access keys
# MAGIC 1. Register Azure AD Application / Service Principal
# MAGIC 2. Generate a secret/password for the application
# MAGIC 3. Set Spark configuration with App/Client Id, Directory/ Tenant Id & Secret
# MAGIC 4. Assign Role 'Storage Blob Data Contributor' to the Data Lake
# MAGIC

# COMMAND ----------

spark.conf.set("fs.azure.account.key.formula1nesodatalake.dfs.core.windows.net", "c/hECt+PRnovkY2to+gmxQeF4B2gVc0fer5cb+wIgkzWP+K9wcQzmWuigyA8W5DgHcGXThKaiVnk+AStl1AyEA==")

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@formula1nesodatalake.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv("abfss://demo@formula1nesodatalake.dfs.core.windows.net/circuits.csv"))